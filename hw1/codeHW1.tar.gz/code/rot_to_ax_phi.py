#!/usr/bin/env python
import numpy as np

def rot_to_ax_phi(R):
	s = 0 # delete and write your own function
	phi = 0
	return (s,phi)
