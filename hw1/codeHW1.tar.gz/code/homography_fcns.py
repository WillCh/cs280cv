#!/usr/bin/env python
import numpy as np

def affine_solve(u,v):
	H = 0 # delete and write your own function
	return H

def homography_solve(u,v):
	H = 0 # delete and write your own function
	return H

def homography_transform(u,H):
	v = 0 # delete and write your own function
	return v
